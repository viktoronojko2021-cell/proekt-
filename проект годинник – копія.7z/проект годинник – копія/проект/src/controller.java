import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.animation.AnimationTimer;


public class controller {

    @FXML
    private Label currentTimeLabel;
    @FXML
    private Label timerLabel;
    @FXML
    private Label stopwatchLabel;

    private long timerStart = 0;
    private boolean timerRunning = false;
    private AnimationTimer timer;

    private long countdownTime = (300) * 1000; // міняйте число в дужках для зміни часу секундоміра
    private long countdownStart = 0;
    private boolean countdownRunning = false;
    private AnimationTimer countdown;

    public void initialize() {
        new AnimationTimer() {
            @Override
            public void handle(long now) {
                java.time.LocalTime time = java.time.LocalTime.now();
                currentTimeLabel.setText(time.toString().substring(0, 8));
            }
        }.start();
    }

    @FXML
    private void startTimer() {
        if (!timerRunning) {
            timerStart = System.currentTimeMillis();
            timerRunning = true;
            timer = new AnimationTimer() {
                @Override
                public void handle(long now) {
                    long elapsed = (System.currentTimeMillis() - timerStart) / 1000;
                    timerLabel.setText(elapsed + " с");
                }
            };
            timer.start();
        }
    }

    @FXML
    private void pauseTimer() {
        if (timerRunning) {
            timer.stop();
            timerRunning = false;
        }
    }

    @FXML
    private void resetTimer() {
        timerRunning = false;
        if (timer != null) timer.stop();
        timerLabel.setText("0 с");
    }

    @FXML
    private void startStopwatch() {
        if (!countdownRunning) {
            countdownStart = System.currentTimeMillis();
            countdownRunning = true;
            countdown = new AnimationTimer() {
                @Override
                public void handle(long now) {
                    long elapsed = System.currentTimeMillis() - countdownStart;
                    long remaining = countdownTime - elapsed;

                    if (remaining <= 0) {
                        remaining = 0;
                        stopwatchLabel.setText("0 с");
                        countdown.stop();
                        countdownRunning = false;
                    } else {
                        stopwatchLabel.setText((remaining / 1000) + " с");
                    }
                }
            };
            countdown.start();
        }
    }

    @FXML
    private void pauseStopwatch() {
        if (countdownRunning) {
            countdown.stop();
            long elapsed = System.currentTimeMillis() - countdownStart;
            countdownTime -= elapsed;
            countdownRunning = false;
        }
    }

    @FXML
    private void resetStopwatch() {
        if (countdown != null) countdown.stop();
        countdownRunning = false;
        countdownTime = 5 * 60 * 1000;
        stopwatchLabel.setText("300 с");
    }
}
